-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mer. 15 mars 2023 à 20:11
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `NetflixPrimePlus`
--

-- --------------------------------------------------------

--
-- Structure de la table `film`
--

CREATE TABLE `film` (
  `IDfilm` int(1) NOT NULL,
  `Date` int(11) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Titre` varchar(255) NOT NULL,
  `Synopsis` text NOT NULL,
  `Prix` float NOT NULL DEFAULT 0,
  `Categorie` varchar(30) NOT NULL,
  `IDRealisateur` int(11) NOT NULL,
  `NomRealisateur` varchar(255) NOT NULL,
  `Co-Realisateur` varchar(255) NOT NULL,
  `bandeAnnonce` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `film`
--

INSERT INTO `film` (`IDfilm`, `Date`, `Image`, `Titre`, `Synopsis`, `Prix`, `Categorie`, `IDRealisateur`, `NomRealisateur`, `Co-Realisateur`, `bandeAnnonce`) VALUES
(1, 2008, 'Iron Man 1.png', 'Iron Man', 'Iron Man est un film d\'action réalisé par Jon Favreau. Le milliardaire Tony Stark, interprété par Robert Downey Jr., construit une armure surpuissante pour échapper à ses ravisseurs et décide ensuite de devenir un super-héros pour combattre le terrorisme. Le film a été un succès critique et commercial, lançant une franchise de films Marvel très populaire.', 7.99, 'Action', 1, 'Jon Favreau', '', 'https://www.youtube.com/watch?v=rDCTb9Gp2qk&ab_channel=MarvelFr'),
(2, 2008, 'Hulk.png', 'L\'incroyable Hulk ', 'L\'incroyable Hulk est un film de super-héros réalisé par Louis Leterrier. Le scientifique Bruce Banner, joué par Edward Norton, se cache et essaie de trouver un remède pour sa condition qui le transforme en une créature verte et puissante connue sous le nom de Hulk. Cependant, il est traqué par l\'armée américaine et doit se battre contre un autre monstre créé par une expérience similaire.', 5.99, 'Action', 2, 'Louis Leterrier', '', 'https://www.youtube.com/watch?v=LCjTxK1B5Pg&ab_channel=Gagtiger'),
(3, 2010, 'Iron Man 2.png', 'Iron Man 2', 'Iron Man 2 est un film de super-héros réalisé par Jon Favreau. Tony Stark (Robert Downey Jr.) révèle publiquement qu\'il est Iron Man et doit faire face à de nouveaux ennemis, notamment Whiplash (Mickey Rourke) et Justin Hammer (Sam Rockwell), qui cherchent à lui voler sa technologie. Pendant ce temps, Tony lutte également contre sa propre mortalité due à l\'empoisonnement au palladium de son réacteur arc.', 7.99, 'Action', 1, 'Jon Favreau', '', 'https://www.youtube.com/watch?v=VdZj2QYTAic&ab_channel=CulturClubFrance'),
(4, 2011, 'Thor.png', 'Thor', 'Thor est un film de super-héros réalisé par Kenneth Branagh. Le puissant guerrier Thor, joué par Chris Hemsworth, est banni d\'Asgard par son père Odin et envoyé sur Terre pour apprendre l\'humilité. Pendant ce temps, son frère Loki (Tom Hiddleston) complote pour prendre le trône d\'Asgard, mettant en danger les deux mondes.', 6.99, 'Action', 3, 'Kenneth Branagh', '', 'https://www.youtube.com/watch?v=pzT3yeV9lT4&ab_channel=SlashersHouse'),
(5, 2011, 'CaptainAmerica.png', 'Captain America First Avenger', 'Captain America : First Avenger est un film de super-héros réalisé par Joe Johnston. Steve Rogers (Chris Evans), un jeune homme frêle mais déterminé, est transformé en super-soldat lors d\'une expérience secrète pendant la Seconde Guerre mondiale. Il devient alors Captain America et combat le maléfique Johann Schmidt, alias Crâne Rouge (Hugo Weaving), qui cherche à dominer le monde avec la technologie avancée d\'HYDRA.', 7.99, 'Action', 4, 'Joe Johnston', '', 'https://www.youtube.com/watch?v=2IxYjodhN_c&ab_channel=FilmsExclu'),
(6, 2012, 'Avengers.png', 'Avengers', 'Avengers est un film de super-héros réalisé par Joss Whedon. Les héros de Marvel, qui comprennent un génie milliardaire en armure, un super-soldat, un dieu nordique, un monstre vert géant, une espionne russe et un archer habile, doivent s\'unir pour affronter l\'ennemi extraterrestre qui menace la Terre.', 9.99, 'Action', 5, 'Joss Whedon', '', 'https://www.youtube.com/watch?v=b-kTeJhHOhc&ab_channel=MarvelFR'),
(7, 1994, 'Lacitedelapeur.png', 'La cité de la peur', 'La Cité de la peur est un film français comique réalisé par Alain Berbérian. Les personnages principaux, Odile Deray, Simon Jérémi et Serge Karamazov, se rendent au Festival de Cannes pour présenter un film d\'horreur, mais sont impliqués dans une série de meurtres étranges.', 7.99, 'Comédie', 6, 'Alain Berberian', '', 'https://www.youtube.com/watch?v=8Drj9uNHgfs&ab_channel=Allocin%C3%A9%7CBandesAnnonces'),
(8, 1998, 'dinerdecons.png', 'Le Dîner de Cons', 'Le Dîner de cons est une comédie française réalisée par Francis Veber. Pierre, un éditeur parisien, organise un dîner hebdomadaire où chaque invité doit amener un \'con\'. Les choses se compliquent lorsqu\'il invite François Pignon, un homme très maladroit qui va semer le chaos dans la soirée. Le film est rempli de situations comiques et d\'humour absurde, et est considéré comme l\'un des classiques de la comédie française.', 6.99, 'Comédie', 7, 'Francis Veber', '', 'https://www.youtube.com/watch?v=wx0mwd9l93Q&ab_channel=Gaumont'),
(9, 1980, 'Avion.png', 'Y\'a t\'il un pilote dans l\'avion ?', 'Y a-t-il un pilote dans l\'avion? est une comédie américaine réalisée par Jim Abrahams. Ted Striker, un ancien pilote de chasse devenu alcoolique, tente de conquérir sa peur de voler pour sauver les passagers d\'un avion de ligne qui est en danger. Le film est rempli de gags visuels, de parodies de films de catastrophe et de scènes comiques mémorables, ce qui en fait un classique de la comédie.', 8.99, 'Comédie', 8, 'Jim Abrahams', 'David Zucker, Jerry Zucker', 'https://www.youtube.com/watch?v=TnRYbC4C6ow&ab_channel=ParamountChannelFrance'),
(10, 1983, 'Les Comperes.png', 'Les Compères', 'Les Compères est une comédie française réalisée par Francis Veber. Les personnages principaux, Jean Lucas et Antoine Brisebard, découvrent qu\'ils ont chacun une fille de 16 ans qui a disparu et décident de partir à sa recherche ensemble. Les deux hommes que tout oppose vont vivre une aventure pleine d\'humour, de quiproquos et de situations comiques inattendues.', 5.99, 'Comédie', 7, 'Francis Veber', '', 'https://www.youtube.com/watch?v=Q_t4EYSHurU&ab_channel=CineComediesBandes-annonces'),
(11, 1981, 'La chevre.png', 'La Chèvre', 'La Chèvre est une comédie française réalisée par Francis Veber. Le détective privé Campana est chargé de retrouver la fille d\'un milliardaire qui a disparu au Mexique, mais il est tellement maladroit qu\'il est contraint de s\'associer à un employé de bureau malchanceux, Perrin. Les deux hommes vont vivre une aventure rocambolesque et remplie d\'humour pour retrouver la jeune femme.', 7.99, 'Comédie', 7, 'Francis Veber', '', 'https://www.youtube.com/watch?v=ORU_r0kDtNo&ab_channel=LeProjectionniste'),
(12, 2002, 'Asterix.png', 'Astérix et Obélix mission cléopatre', 'Astérix et Obélix : Mission Cléopâtre est une comédie française réalisée par Alain Chabat. Le film est une adaptation de la bande dessinée d\'Astérix créée par René Goscinny et Albert Uderzo. Astérix et Obélix sont chargés par Cléopâtre de construire un palais en trois mois pour impressionner César et éviter l\'invasion de l\'Égypte. Le film est célèbre pour son humour absurde, ses effets spéciaux impressionnants et son casting de choix.', 9.99, 'Comédie', 9, 'Alain Chabat', '', 'https://www.youtube.com/watch?v=DR1a7R5usts&ab_channel=YvesLemerce'),
(13, 2002, 'Spiderman.png', 'Spider-Man', 'Spider-Man est un film de super-héros américain réalisé par Sam Raimi. Le film suit l\'histoire de Peter Parker, un étudiant ordinaire qui acquiert des super-pouvoirs après avoir été mordu par une araignée radioactive. Il décide alors d\'utiliser ses pouvoirs pour combattre le crime en tant que Spider-Man.', 5.99, 'Action', 10, 'Sam Raimi', '', 'https://www.youtube.com/watch?v=dx41JSGrubc&ab_channel=MemberMovies'),
(14, 2018, 'Spiderman spiderverse.png', 'Spider-Man: Into the Spider-Verse', 'Spider-Man: Into the Spider-Verse est un film d\'animation américain réalisé par Bob Persichetti. Le film suit l\'histoire de Miles Morales, un adolescent de Brooklyn qui devient le Spider-Man de sa réalité après avoir été mordu par une araignée radioactive. Il rencontre alors d\'autres versions de Spider-Man venant de différentes réalités et doit collaborer avec eux pour sauver leur univers.', 9.99, 'Action', 11, 'Bob Persichetti', 'Peter Ramsey, Rodney Rothman', 'https://www.youtube.com/watch?v=-AnN_Xg2Nps&ab_channel=SonyPicturesFr'),
(15, 2009, 'lahaut.png', 'Là-haut', 'Là-haut est un film d\'animation américain réalisé par Pete Docter. Le film suit l\'histoire de Carl Fredricksen, un vieil homme solitaire qui réalise son rêve d\'enfant en attachant des milliers de ballons à sa maison pour s\'envoler vers l\'Amérique du Sud. Cependant, il découvre qu\'un jeune scout nommé Russell s\'est accidentellement retrouvé sur sa maison volante et les deux se lancent dans une aventure remplie d\'humour et d\'émotions.', 7.99, 'Comédie', 12, 'Pete Docter', 'Bob Peterson', 'https://www.youtube.com/watch?v=p-TdCD6DBfM&ab_channel=DisneyFR'),
(16, 2020, 'Soul.png', 'Soul', 'Soul est un film d\'animation américain réalisé par Pete Docter. Le film suit l\'histoire de Joe Gardner, un professeur de musique passionné qui a l\'opportunité de jouer dans le meilleur club de jazz de la ville. Cependant, après un accident, son âme est transportée dans le \"Grand Avant\", un lieu où les âmes se forment avant de naître. Là-bas, il rencontre une âme nommée 22 et ensemble, ils entreprennent un voyage pour découvrir le but de la vie.', 6.99, 'Comédie', 12, 'Pete Docter', '', 'https://www.youtube.com/watch?v=3IZkCUGGhgY&ab_channel=DisneyFR'),
(17, 2008, 'Linstinctdemort.png', 'L\'instinct de mort', 'L\'instinct de mort\", \"L\'instinct de mort est un film français réalisé par Jean-François Richet. Le film est une adaptation du livre éponyme de Jacques Mesrine, un célèbre criminel français des années 60 et 70. Le film suit l\'histoire de Mesrine, depuis ses débuts modestes jusqu\'à sa vie de crime en tant que braqueur de banques et fugitif recherché par la police.', 8.99, 'Action', 13, 'Jean-François Richet', '', 'https://www.youtube.com/watch?v=2FIx161gnH0&ab_channel=SuperBeri'),
(18, 1994, 'Leon.png', 'Léon', 'Léon est un film français réalisé par Luc Besson. Le film suit l\'histoire de Léon, un tueur à gages solitaire et taciturne qui vit à New York. Lorsque Mathilda, une jeune fille de 12 ans, voit sa famille se faire assassiner par un policier corrompu, elle se tourne vers Léon pour apprendre le métier de tueur à gages et se venger.', 7.99, 'Action', 14, 'Luc Besson', '', 'https://www.youtube.com/watch?v=vSi5jdziv3I&ab_channel=Gaumont'),
(19, 2006, 'OSS 117.png', 'OSS 117 : Le Caire, nid d\'espions', 'OSS 117 : Le Caire, nid d\'espions\", \"OSS 117 : Le Caire, nid d\'espions est une comédie française réalisée par Michel Hazanavicius. Le film suit les aventures de l\'agent secret Hubert Bonisseur de La Bath, alias OSS 117, envoyé au Caire pour enquêter sur la disparition d\'un de ses collègues. Sur place, il doit faire face à des ennemis redoutables tout en tentant de séduire sa coéquipière, la belle princesse Al Tarouk.', 6.99, 'Comédie', 15, 'Michel Hazanavicius', '', 'https://www.youtube.com/watch?v=l3TsZdc-m3U&ab_channel=LeProjectionniste'),
(20, 1982, 'AvantJC.png', 'Deux Heures moins le quart avant Jésus-Christ', 'Deux heures moins le quart avant Jésus-Christ est une comédie française réalisée par Jean Yanne. Le film suit les aventures de Ben Hur Marcel, un esclave malchanceux qui doit transporter la croix du Christ jusqu\'à Golgotha. Sur sa route, il rencontre des personnages hauts en couleur tels que Ponce Pilate, Cléopâtre et Jules César.', 5.99, 'Comédie', 16, 'Jean Yanne', '', 'https://www.youtube.com/watch?v=Pe1XuBsiVB8&ab_channel=Pathe');

-- --------------------------------------------------------

--
-- Structure de la table `realisateur`
--

CREATE TABLE `realisateur` (
  `IDRealisateur` int(1) NOT NULL,
  `image` varchar(255) NOT NULL,
  `Age` date NOT NULL,
  `Genre` varchar(255) NOT NULL,
  `Films` varchar(255) NOT NULL,
  `Nom` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `realisateur`
--

INSERT INTO `realisateur` (`IDRealisateur`, `image`, `Age`, `Genre`, `Films`, `Nom`) VALUES
(1, 'jonfavreau.png', '1966-10-19', 'Homme', 'Iron Man, Iron Man 2', 'Jon Favreau'),
(2, 'louisleterrier.png', '1973-06-17', 'Homme', 'L\'incroyable Hulk', 'Louis Leterrier'),
(3, 'kennethbranagh.png', '1960-12-10', 'Homme', 'Thor', 'Kenneth Branagh'),
(4, 'joejohnston.png', '1950-05-13', 'Homme', 'Captain America First Avenger', 'Joe Johnston'),
(5, 'josswhedon.png', '1964-06-23', 'Homme', 'Avengers', 'Joss Whedon'),
(6, 'alainberberian.png', '1953-07-02', 'Homme', 'La cité de la peur', 'Alain Berberian'),
(7, 'francisveber.png', '1937-07-28', 'Homme', 'Le diner de cons, La chèvre, Les compères', 'Francis Veber'),
(8, 'jimarahams.png', '1944-11-10', 'Homme', 'Y a t\'il un pilote dans l\'avion?', 'Jim Abrahams'),
(9, 'alainchabat.png', '1958-11-24', 'Homme', 'Astérix et Obélix Mission Cléopatre', 'Alain Chabat'),
(10, 'samraimi.png', '1959-11-23', 'Homme', 'Spiderman', 'Sam Raimi'),
(11, 'bobpersichetti.png', '1973-01-17', 'Homme', 'Spider Man Into the Spiderverse', 'Bob Persichetti'),
(12, 'petedocter.png', '1968-10-08', 'Homme', 'Là-haut, Soul', 'Pete Docter'),
(13, 'jeanfrancoisrichet.png', '1966-07-02', 'Homme', 'L\'instinct de mort', 'Jean-François Richet'),
(14, 'lucbesson.png', '1959-03-18', 'Homme', 'Léon', 'Luc Besson'),
(15, 'michelhazanavicius.png', '1967-03-29', 'Homme', 'OSS 117', 'Michel Hazanavicius'),
(16, 'jeanyanne.png', '1933-07-18', 'Homme', 'Deux heures moins le quart avant Jésuis Christ', 'Jean Yanne');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `ID` int(255) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`ID`, `username`, `email`, `password`) VALUES
(8, 'Popol', 'paul.preuvost@supinfo.com', '$2y$10$o8VZx9b8EhVVAUEp3yigeOfHg./dD6BNrtv//IUxHCFKF.ayA0FnO'),
(11, 'Télio', 'papreuvost@gmail.com', '$2y$10$KZN1xiU.L7lfP4w664KKIuUiwbHJQJCZbUkWs3Hwf7UgZrJu2fSzW'),
(12, 'admin', 'Test@gmail.com', '$2y$10$nCAa8QTjYy4Ixv5q/eglTeQX6Y.hK1MHJFyzBzelJ1VAG7OhFUE2.'),
(13, 'nosijex', 'rahiwy@mailinator.com', '$2y$10$SlesHmeAgnBYDH6eEH0WHewLg.ql5eDB9fvmn3Yi4kr2mTjfSXPkG'),
(14, 'nelosededo', 'ronyqet@mailinator.com', '$2y$10$H.cJIJg6Sy0N1ZhAfg5mx.lL/aM..MfAnrXUiLiLcdjSZTN0ZcGU2'),
(15, 'hugixixu', 'lemogevep@mailinator.com', '$2y$10$w16P4t37BEi4HP7ciqzBX.XXldiaV3CVwE3dhMfq7oeCctTE2n05q'),
(16, 'xovuqamux', 'fewovidyne@mailinator.com', '$2y$10$xf.KtOW3RWKktddOSEhHSe1vxnYS5xkQiE98AP5dRvvLLgjRcqRkS'),
(17, 'admin', 'po@gmail.com', '$2y$10$of0pm850Ik8CtCVJFrpJbehjf.B4jq5mken2PsP9q0e8ooNHQXGc6');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`IDfilm`),
  ADD KEY `fk_film_realisateur` (`IDRealisateur`);

--
-- Index pour la table `realisateur`
--
ALTER TABLE `realisateur`
  ADD PRIMARY KEY (`IDRealisateur`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `film`
--
ALTER TABLE `film`
  MODIFY `IDfilm` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `realisateur`
--
ALTER TABLE `realisateur`
  MODIFY `IDRealisateur` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `film`
--
ALTER TABLE `film`
  ADD CONSTRAINT `fk_film_realisateur` FOREIGN KEY (`IDRealisateur`) REFERENCES `realisateur` (`IDRealisateur`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
